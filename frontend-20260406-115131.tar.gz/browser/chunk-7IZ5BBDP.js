var o=typeof window<"u"&&(window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"),t=o?"https://localhost:7278":"https://api.geourp.org";export{t as a};
